# frozen_string_literal: true

require 'test_helper'

class RoomTest < ActiveSupport::TestCase
end
