# frozen_string_literal: true

# Application Helper Module
module ApplicationHelper
end
