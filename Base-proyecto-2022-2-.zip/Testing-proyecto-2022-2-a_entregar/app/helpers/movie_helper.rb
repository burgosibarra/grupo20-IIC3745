# frozen_string_literal: true

# Movie Helper module
module MovieHelper
end
