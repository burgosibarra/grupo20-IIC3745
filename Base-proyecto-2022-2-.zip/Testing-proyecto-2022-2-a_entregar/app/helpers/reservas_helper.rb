# frozen_string_literal: true

# Reservas Helper module
module ReservasHelper
end
