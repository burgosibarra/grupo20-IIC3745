# frozen_string_literal: true

class Room < ApplicationRecord
end
