# Proyecto DCCinema Grupo X
#### Entrega: X
#### Url Heroku:


### Logros
 Dejar explicito lo que no lograron hacer de la entrega o si lograron hacer todo lo pedido

### Consideraciones generales para la correcion
Cualquier detalle que consideren que puede ser útil para el corrector. Ej:
bugs detectados, pasos adicionales de setup, cosas que no sean tan claras relacionadas con el uso de su aplicacion, entre otros

